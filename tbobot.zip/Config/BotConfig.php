<?php
    define ('BOTNAME', 'sonvipbot');
    define ('TOKEN', '6060592598:AAEUITOX8jm_ZuOyldf6l6ThnckRLI0B-5s');
    define ('MASTER', '1283520615');
     define ('TRXADD', 'TSCBYxKnLbLGPkcjZddWB4b64ymTdpcyY3');
    define ('FASTLOGIN', false);
    define ('DEBUG', false);
