<?php
    define ('DBHOST', '127.0.0.1');
    define ('DBNAME', 'k_et15_com');
    define ('DBUSER', 'k_et15_com');
    define ('DBPASS', 'yzRSDPKcaxX3Cp2M');
    define ('DBPERSISTENT', false);
